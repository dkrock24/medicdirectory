<?php
$schedule = $_REQUEST['schedule'];
var_dump($schedule);

?>